<?php

namespace suprasac;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use DB;

class Category extends Model
{
    //
}
