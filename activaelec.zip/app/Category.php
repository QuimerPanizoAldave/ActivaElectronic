<?php

namespace ActivaElectronic;
use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use DB;

class Category extends Model
{
    //
}
