<?php

namespace ActivaElectronic\Events;

abstract class Event
{
    //
}
