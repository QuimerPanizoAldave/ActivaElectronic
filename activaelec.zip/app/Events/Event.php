<?php

namespace suprasac\Events;

abstract class Event
{
    //
}
