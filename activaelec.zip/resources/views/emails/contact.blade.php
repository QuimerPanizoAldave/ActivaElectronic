<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>CONTACTAR A CLIENTE</title>
	</head>
	<body>

		<p><strong>Nombre:</strong>{!!$name!!}</p>
		<p><strong>Email:</strong>{!!$email!!}</p>
		<p><strong>Telefono:</strong>{!!$telefono!!}</p>
		<p><strong>Mensaje:</strong>{!!$mensaje!!}</p>
	</body>
</html>