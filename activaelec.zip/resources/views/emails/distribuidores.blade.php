<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>REGISTRO DE DISTRIBUIDORES</title>
	</head>
	<body>
		<p><strong>Razon:</strong>{!!$name!!}</p>
		<p><strong>Ruc:</strong>{!!$ruc!!}</p>
		<p><strong>Direccion:</strong>{!!$direccion!!}</p>
		<p><strong>Distrito:</strong>{!!$distrito!!}</p>
		<p><strong>Departamento:</strong>{!!$departamento!!}</p>
		<p><strong>Email:</strong>{!!$email!!}</p>
		<p><strong>Telefono:</strong>{!!$telefono!!}</p>
		<p><strong>Pagina web:</strong>{!!$web!!}</p>
	</body>
</html>